create
    definer = root@localhost procedure UpdateUser(IN p_user_id int, IN p_email varchar(255), IN p_username varchar(100),
                                                  IN p_first_name varchar(100), IN p_last_name varchar(100),
                                                  IN p_phone varchar(50), IN p_role varchar(50), IN p_is_active tinyint)
BEGIN
  START TRANSACTION;
    UPDATE users
    SET email = p_email,
        username = p_username,
        first_name = p_first_name,
        last_name = p_last_name,
        phone = p_phone,
        role = COALESCE(p_role, role),
        is_active = p_is_active,
        updated_at = NOW()
    WHERE id = p_user_id;
  COMMIT;
END;

