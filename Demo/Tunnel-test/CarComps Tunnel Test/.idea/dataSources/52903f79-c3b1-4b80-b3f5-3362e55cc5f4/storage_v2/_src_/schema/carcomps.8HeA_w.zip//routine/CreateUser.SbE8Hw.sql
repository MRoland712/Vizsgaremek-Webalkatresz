create
    definer = root@localhost procedure CreateUser(IN p_email varchar(255), IN p_username varchar(100),
                                                  IN p_password_hash varchar(255), IN p_first_name varchar(100),
                                                  IN p_last_name varchar(100), IN p_phone varchar(50),
                                                  IN p_role varchar(50))
BEGIN
  START TRANSACTION;
    INSERT INTO users (
      email, username, password, first_name, last_name, phone,
      role, is_active, created_at, updated_at
    ) VALUES (
      p_email, p_username, p_password_hash, p_first_name, p_last_name, p_phone,
      COALESCE(p_role, 'user'), 1, NOW(), NOW()
    );
    SELECT LAST_INSERT_ID() AS new_user_id;
  COMMIT;
END;

