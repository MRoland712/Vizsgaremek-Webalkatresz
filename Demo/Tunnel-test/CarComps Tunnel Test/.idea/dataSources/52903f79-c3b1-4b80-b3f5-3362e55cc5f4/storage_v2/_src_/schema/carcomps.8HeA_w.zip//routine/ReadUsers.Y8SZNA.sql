create
    definer = root@localhost procedure ReadUsers()
BEGIN
    SELECT id, email, username, first_name, last_name,
           phone, role, is_active, created_at, updated_at
    FROM users
    ORDER BY id;
END;

