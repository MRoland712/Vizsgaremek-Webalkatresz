create
    definer = root@localhost procedure DeleteUser(IN p_user_id int)
BEGIN
  START TRANSACTION;
    DELETE FROM addresses WHERE user_id = p_user_id;
    DELETE FROM users WHERE id = p_user_id;
  COMMIT;
END;

