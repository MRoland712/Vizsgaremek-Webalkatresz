create
    definer = root@localhost procedure ReadUserById(IN p_user_id int)
BEGIN
  SELECT id, email, username, first_name, last_name, phone, role, is_active, created_at, updated_at
  FROM users 
  WHERE id = p_user_id;
END;

