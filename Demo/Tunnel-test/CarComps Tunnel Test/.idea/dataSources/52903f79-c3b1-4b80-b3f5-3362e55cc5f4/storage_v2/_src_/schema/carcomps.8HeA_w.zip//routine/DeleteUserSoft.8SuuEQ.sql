create
    definer = root@localhost procedure DeleteUserSoft(IN p_user_id int)
BEGIN
  START TRANSACTION;
    UPDATE users SET is_deleted = 1, deleted_at = NOW() WHERE id = p_user_id;
    UPDATE addresses SET is_deleted = 1, deleted_at = NOW() WHERE user_id = p_user_id;
  COMMIT;
END;

